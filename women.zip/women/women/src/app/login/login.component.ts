import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthService } from '../authservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginMessage: string = '';
  loginSuccess: boolean = false;
  signupMessage: string = '';
  signupSuccess: boolean = false;

  private apiUrl = 'http://localhost:3000/users';

  constructor(private http: HttpClient,private router:Router,private authService:AuthService) {}

  onLoginSuccess() {
  this.authService.login();
}



  // Login submit handler
  onLogin(form: any) {
    this.loginMessage = ''; // Reset message at submit
    this.loginSuccess = false;

    if (form.invalid) return;
    const { email, password } = form.value;

    this.http.get<any[]>(`${this.apiUrl}?email=${email}&password=${password}`).subscribe(
      users => {
        if (users.length === 1) {
          this.loginSuccess = true;
          this.loginMessage = 'Login successful!';
           this.authService.login();
          setTimeout(()=>{
            this.router.navigate([''])
          })
        } else {
          this.loginSuccess = false;
          this.loginMessage = 'Login failed: Incorrect email or password.';
        }
      },
      error => {
        this.loginSuccess = false;
        this.loginMessage = 'An error occurred.';
      }
    );
  }

  // Signup submit handler
  onSignup(form: any) {
    this.signupMessage = ''; // Reset message at submit
    this.signupSuccess = false;
    if (form.invalid) return;
    const { username, new_email, newpassword } = form.value;

    this.http.get<any[]>(`${this.apiUrl}?email=${new_email}`).subscribe(
      users => {
        if (users.length > 0) {
          this.signupSuccess = false;
          this.signupMessage = 'Signup failed: User already exists!';
        } else {
          // Create new user
          const newUser = {
            username: username,
            email: new_email,
            password: newpassword
          };
          this.http.post<any>(this.apiUrl, newUser).subscribe(
            res => {
              this.signupSuccess = true;
              this.signupMessage = 'Signup successful!';
              form.resetForm();
            },
            err => {
              this.signupSuccess = false;
              this.signupMessage = 'An error occurred during signup.';
            }
          );
        }
      },
      err => {
        this.signupSuccess = false;
        this.signupMessage = 'An error occurred during signup.';
      }
    );
  }
}

import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {

  cartItems: any[] = [];
 

  constructor(private cartService: CartService, private router: Router) {}

  ngOnInit() {
    this.cartItems = this.cartService.getCart();  
  }

 removeItem(i: number) {
  this.cartService.removeFromCart(i);
  this.cartItems = this.cartService.getCart();
}


  get total() {
    return this.cartItems.reduce((sum, item) => sum + (item.price * (item.quantity || 1)), 0);
  }
  increaseQty(id: number) {
    this.cartService.increaseQuantity(id);
    this.cartItems = this.cartService.getCart();
  }

  decreaseQty(id: number) {
    this.cartService.decreaseQuantity(id);
    this.cartItems = this.cartService.getCart();
  }
  checkout() {
    this.router.navigate(['/payment'], {
      state: { totalAmount: this.total }
    });
  }
 clearCart() {
  localStorage.removeItem('cart');
}


}
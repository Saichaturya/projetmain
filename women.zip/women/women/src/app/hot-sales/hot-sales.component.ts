import { Component ,OnInit} from '@angular/core';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';
import { AuthService } from '../authservice.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
// ... other imports
interface HotSaleProduct {
  id: number;
  name: string;
  price: number;
  image: string;
  sale?: boolean;
}


@Component({
  selector: 'app-hot-sales',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './hot-sales.component.html',
  styleUrls: ['./hot-sales.component.css'] // correct property name!
})
export class HotSalesComponent implements OnInit {
  hotsales: HotSaleProduct[] = [];

  constructor(
    private cartService: CartService,
    private productService: ProductService,
    private authService: AuthService,
    private router: Router,
    private dataService: ProductService
  ) {}

  ngOnInit() {
    this.dataService.getProducts('hotsales').subscribe((data: HotSaleProduct[]) => {
      this.hotsales = data;
    });
  }

  addToCart(product: HotSaleProduct) {
    if (!this.authService.isLoggedIn()) {
      alert("You must log in to add products to cart.");
      this.router.navigate(['/login']);
      return;
    }
    this.cartService.addToCart(product);
    alert(`${product.name} added to cart!`);
  }
}
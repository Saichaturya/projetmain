import { Component, OnInit } from '@angular/core';
import { AuthService } from '../authservice.service';
import { Router } from '@angular/router';
import { CartService } from '../cart.service';   // <-- IMPORTANT

@Component({
  selector: 'app-headers',
  templateUrl: './headers.component.html',
  styleUrls: ['./headers.component.css']
})
export class HeadersComponent implements OnInit {

  cartCount: number = 0;
  isLoggedIn = false;

  constructor(
    private authService: AuthService,
    private router: Router,
    private cartService: CartService   // <-- include here
  ) {}

  ngOnInit() {

    // ✅ LIVE CART COUNT UPDATE
    this.cartService.cartCount$.subscribe(count => {
      this.cartCount = count;
    });

    // ✅ LOGIN STATUS CHECK
    this.authService.isLoggedIn$.subscribe(flag => {
      this.isLoggedIn = flag;
    });

    this.authService.checkLoginPersisted();
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}

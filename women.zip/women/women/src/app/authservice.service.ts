import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  // Use BehaviorSubject so late subscribers get current value
  private loggedIn = new BehaviorSubject<boolean>(false);

  // Observable for components to subscribe to
  get isLoggedIn$(): Observable<boolean> {
    return this.loggedIn.asObservable();
  }

  // Method to set login state when user logs in
  login(): void {
    this.loggedIn.next(true);
    // Persist state if desired
    localStorage.setItem('loggedIn', 'true');
  }

  // Method to set state/log user out
  logout(): void {
    this.loggedIn.next(false);
    localStorage.removeItem('loggedIn');
  }

  // Optionally call this on app start to restore persisted state
  checkLoginPersisted(): void {
    const isLogged = localStorage.getItem('loggedIn') === 'true';
    this.loggedIn.next(isLogged);
  }
  isLoggedIn(): boolean {
  return this.loggedIn.value; // returns true/false
}

}
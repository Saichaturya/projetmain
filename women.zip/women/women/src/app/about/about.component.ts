import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
   sections = [
    {
      heading: 'Our Services',
      cards: [
        {
          title: 'Fast & Secure Delivery',
          description: `We partner with trusted courier services to ensure your orders reach you quickly 
            and safely. Real-time tracking and express delivery options make your shopping smooth and worry-free.`
        },
        {
          title: 'Premium Quality Assurance',
          description: `Every product undergoes multiple quality checks — fabric, stitching, sizing accuracy, 
            and overall comfort — ensuring you get the best value and durability every time you shop.`
        },
        {
          title: 'Hassle-Free Returns',
          description: `We offer easy returns and replacements with transparent conditions.  
            If something doesn’t fit or match your expectations, we’re here to help — no complications.`
        }
      ]
    },
    {
      heading: 'Our Policies',
      cards: [
        {
          title: 'Privacy Policy',
          description: `Your personal data is encrypted and securely stored.  
            We do not share your information with third parties.  
            Your privacy and trust remain our top priority.`
        },
        {
          title: 'Return & Refund Policy',
          description: `Returns are accepted within 7-10 days of delivery. Refunds are processed quickly after 
            quality inspection. We ensure transparent, customer-friendly return rules.`
        },
        {
          title: 'Shipping Policy',
          description: `Orders are dispatched within 24 hours. Delivery timelines vary between 2-5 days based on location.  
            We ensure prompt handling of every order for timely delivery.`
        }
      ]
    },
    {
      heading: 'Why Choose Us?',
      cards: [
        {
          title: 'Trendy & Updated Styles',
          description: `We regularly update our collections based on global fashion trends, keeping you ahead 
            in style — whether it’s casual, ethnic, officewear, or party collections.`
        },
        {
          title: 'Affordable Luxury',
          description: `High-quality fashion doesn’t have to be expensive.  
            We offer premium fabric and modern designs at prices that fit your budget.`
        },
        {
          title: 'Customer-First Approach',
          description: `Our support team is available 24/7 to help with product selection, order updates, 
            return requirements, or any questions you may have.`
        }
      ]
    }
  ];

}

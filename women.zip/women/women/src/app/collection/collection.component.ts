import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../product.service';
import { CartService } from '../cart.service';
interface CollectionItem {
  image: string;
  alt: string;
  title: string;
  btnLabel: string;
  link: string;
  contentClass: string;
  overlayClass: string;
}
 
@Component({
  selector: 'app-collection',
    standalone: true,
  imports: [CommonModule],
  templateUrl: './collection.component.html',
  styleUrls: ['./collection.component.css']
})
export class CollectionComponent {
  collections: CollectionItem[] = [
   
  ];
  constructor(private dataService: ProductService) {}
 
  ngOnInit() {
    this.dataService.getProducts('collections').subscribe((data: any) => {
      this.collections = data;  
    });
  }
  
 
}
 
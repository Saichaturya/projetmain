import { Component } from '@angular/core';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';
import { AuthService } from '../authservice.service';
import { Router } from '@angular/router';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  sale?: boolean;
}

@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent {

  constructor(
    private cartService: CartService,
    private productService: ProductService,
    private authService: AuthService,     // ✅ added
    private router: Router                // ✅ added
  ) {}

  products: Product[] = [];

  minPrice: number = 100;
  maxPrice: number = 400;
  selectedMax: number = this.maxPrice;

  sortOrder: string = 'Ascending prices';

  ngOnInit() {
    this.productService.getProducts('clothing').subscribe(data => {
      this.products = data;
    });
  }

  get filteredProducts(): Product[] {
    let filtered = this.products.filter(p => p.price <= this.selectedMax);

    if (this.sortOrder === 'Ascending prices') {
      filtered = filtered.sort((a, b) => a.price - b.price);
    } else if (this.sortOrder === 'Descending prices') {
      filtered = filtered.sort((a, b) => b.price - a.price);
    }

    return filtered;
  }

  updatePrice(event: Event): void {
    const input = event.target as HTMLInputElement;
    this.selectedMax = +input.value;
  }

  sortProducts(event: Event): void {
    const select = event.target as HTMLSelectElement;
    this.sortOrder = select.value;
  }

  
  addToCart(product: Product) {
    if (!this.authService.isLoggedIn()) {
      alert("You must log in to add products to cart.");
      this.router.navigate(['/login']);   // redirect to login page
      return;
    }

    this.cartService.addToCart(product);
    alert(`${product.name} added to cart!`);
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../cart.service';


@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
   totalAmount: number = 0;

  constructor(private router: Router, private cartService: CartService) {
    
    const state = history.state;
    this.totalAmount = state.totalAmount || 0;
  }
fullName: string = '';
email: string = '';
upiId: string = '';

emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
upiPattern = /^[a-zA-Z0-9.\-_]{3,}@[a-zA-Z]{2,}$/;  // Example: name@ybl

isFormValid() {
  return (
    this.fullName.trim().length > 2 &&
    this.emailPattern.test(this.email) &&
    this.upiPattern.test(this.upiId)
  );
}

payNow() {
  if (!this.isFormValid()) {
    alert("Please enter all details in correct format!");
    return;
  }
  alert("Processing Payment...");

setTimeout(() => {
    alert("🎉 Payment Successful!");
    this.cartService.clearCart();  
    
  }, 1200);


}

}

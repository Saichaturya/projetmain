import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../product.service';
import { CartService } from '../cart.service';
import { AuthService } from '../authservice.service';
import { Router } from '@angular/router';
interface TopSaleItem {
  name: string;
  image: string;
  price: string;
 
}
@Component({
  selector: 'app-top-sales',
   standalone: true,
  imports: [CommonModule],
  templateUrl: './top-sales.component.html',
  styleUrl: './top-sales.component.css'
})
export class TopSalesComponent {
topsales: TopSaleItem[] = [
   
  ];
  constructor(
    private cartService: CartService,
    private productService: ProductService,
    private authService: AuthService,
    private router: Router,
    private dataService: ProductService
  ) {}

 
 
  ngOnInit() {
    this.dataService.getProducts('topSales').subscribe((data: any) => {
      this.topsales = data;  
    });
  }
  addToCart(product: TopSaleItem) {
    if (!this.authService.isLoggedIn()) {
      alert("You must log in to add products to cart.");
      this.router.navigate(['/login']);
      return;
    }
    this.cartService.addToCart(product);
    alert(`${product.name} added to cart!`);
  }
 
}
 
 
import { Component } from '@angular/core';
import { FooterComponent } from "./footer/footer.component";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  // imports: [FooterComponent]
})
export class AppComponent {
  title = 'women';
 

}

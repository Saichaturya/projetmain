import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { HeadersComponent } from './headers/headers.component';
import { ClothingComponent } from './clothing/clothing.component';
import { HomeComponent } from './home/home.component';
import { RouterModule } from '@angular/router';
import { JewelleryComponent } from './jewellery/jewellery.component';
import { CartComponent } from './cart/cart.component';
import { SkincareComponent } from './skincare/skincare.component';
import { CollectionComponent } from './collection/collection.component';
import { HotSalesComponent } from './hot-sales/hot-sales.component';
import { NewArrivalsComponent } from './new-arrivals/new-arrivals.component';
import { TopSalesComponent } from './top-sales/top-sales.component';
import { AboutComponent } from './about/about.component';
import { FooterComponent } from './footer/footer.component';
import { ContactComponent } from './contact/contact.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    HeadersComponent,
    ClothingComponent,
    HomeComponent,
    JewelleryComponent,
    CartComponent,
    SkincareComponent,
    FooterComponent,
    AboutComponent,
    ContactComponent,
    LoginComponent,
    PaymentComponent,
   
    
  ],
  imports: [
    BrowserModule,
     FormsModule,
    CommonModule,
    CollectionComponent,
    HotSalesComponent,
    NewArrivalsComponent,
    TopSalesComponent,
    HttpClientModule,
    RouterModule.forRoot([
     { path: '', component: HomeComponent },
      { path: 'clothing', component: ClothingComponent },
      { path: 'jewellery', component: JewelleryComponent },
      { path: 'cart', component: CartComponent },
      { path: 'skincare', component: SkincareComponent },  
      {path:'about',component:AboutComponent},
      {path:'contact',component:ContactComponent},
      {path:'login',component:LoginComponent},
      {path:'payment',component:PaymentComponent},

    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

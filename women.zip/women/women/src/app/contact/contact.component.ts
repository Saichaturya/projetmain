import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {
 
  contact = {
    name: '',
    email: '',
    message: ''
  };
  formSubmitted = false;

  onSubmit(form: any) {
    if (form.valid) {
      // In production, send your data here (HTTP service, etc.)
      this.formSubmitted = true;
      form.resetForm();
      setTimeout(() => this.formSubmitted = false, 5000);
    }
  }
}



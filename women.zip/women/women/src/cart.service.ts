import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private cartItems: any[] = [];

  // 🔥 This will update the cart count everywhere
  private cartCountSubject = new BehaviorSubject<number>(0);
  cartCount$ = this.cartCountSubject.asObservable();

  constructor() {
    this.loadCart();      // Load cart on refresh
    this.updateCartCount(); // Update count on startup
  }

  // Save cart to localStorage
  private saveCart(): void {
    localStorage.setItem('cart', JSON.stringify(this.cartItems));
    this.updateCartCount(); // <-- update count whenever cart changes
  }

  private loadCart(): void {
    const savedCart = localStorage.getItem('cart');
    this.cartItems = savedCart ? JSON.parse(savedCart) : [];
  }

  // 🔥 Update cart count
  private updateCartCount() {
    const totalCount = this.cartItems.reduce((sum, item) => sum + item.quantity, 0);
    this.cartCountSubject.next(totalCount);
  }

  // Add to cart
  addToCart(product: any) {
    const exists = this.cartItems.find(item => item.id === product.id);

    if (exists) {
      exists.quantity = (exists.quantity || 1) + 1;
    } else {
      this.cartItems.push({ ...product, quantity: 1 });
    }

    this.saveCart();
  }

  // Get cart items
  getCart() {
    return this.cartItems;
  }

  // Remove by ID
  removeFromCart(id: number): void {
    this.cartItems = this.cartItems.filter(item => item.id !== id);
    this.saveCart();
  }

  // Increase quantity
  increaseQuantity(id: number) {
    const item = this.cartItems.find(i => i.id === id);
    if (item) {
      item.quantity++;
      this.saveCart();
    }
  }

  // Decrease quantity
  decreaseQuantity(id: number) {
    const item = this.cartItems.find(i => i.id === id);
    if (!item) return;

    if (item.quantity > 1) {
      item.quantity--;
    } else {
      this.removeFromCart(id);
    }

    this.saveCart();
  }

  // Clear cart
  clearCart(): void {
    this.cartItems = [];
    this.saveCart();
  }
}
